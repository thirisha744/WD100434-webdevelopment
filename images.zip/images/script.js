function openModal(img) {
    document.getElementById("imageModal").style.display = "flex";
    document.getElementById("modalImage").src = img.src;
}

function closeModal() {
    document.getElementById("imageModal").style.display = "none";
}

function filterImages(category) {
    let images = document.querySelectorAll(".gallery img");

    images.forEach(img => {
        if (category === "all" || img.classList.contains(category)) {
            img.style.display = "block";
        } else {
            img.style.display = "none";
        }
    });
}

function uploadImage() {
    let fileInput = document.getElementById("imageUpload");
    let file = fileInput.files[0];

    if (file) {
        let reader = new FileReader();
        reader.onload = function (e) {
            let newImage = document.createElement("img");
            newImage.src = e.target.result;
            newImage.classList.add("image", "uploaded");
            newImage.onclick = function () { openModal(newImage); };
            document.getElementById("gallery").appendChild(newImage);
        };
        reader.readAsDataURL(file);
    } else {
        alert("Please select an image to upload.");
    }
}
